#Variaveis
Pessoa1 = 1.58
Pessoa2 = 1.20

# Verificar valores
if Pessoa1 > Pessoa2:
    print("A pessoa1 é mais alta doque a Pessoa2. ")

else: 
    print("A pessoa2 é mais alta doque a Pessoa1. ")