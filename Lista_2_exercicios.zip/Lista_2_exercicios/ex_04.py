nota = int(input("Informe a sua nota: "))

# Uso do If ternário
alerta = "Você está aprovado" if nota > 5 else "Você está reprovado"

# Exibição
print(alerta)