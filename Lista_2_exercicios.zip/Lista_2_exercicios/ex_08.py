print("=====ALUNOS=====")
print(" ")

# Array das lojas
alunos = ["Luara", "Bernardo", "Fátima", "Lorena"]

# Exibindo lojas
for i, loja in enumerate(alunos, 1):
    print(f"{i} - {loja}")
    print(" ")

