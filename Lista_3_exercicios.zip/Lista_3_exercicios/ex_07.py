while True:
    print("Menu de opções:")
    print("1 - Eu programo em Python")
    print("2 - Eu programo em PHP")
    print("3 - Eu programo em Java")
    opcao = input("Selecione uma opção: ")

    if opcao == "1":
        print("Eu estou estudando Python!")
        break
    elif opcao == "2":
        print("Eu estou estudando PHP!")
        break
    elif opcao == "3":
        print("Eu estou estudando Java!")
        break
    else:
        print("Opção inválida. Por favor, selecione uma opção válida.")