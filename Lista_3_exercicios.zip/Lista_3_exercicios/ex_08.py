
j = 0

while j <= 10:
    print(j)
    j += 2