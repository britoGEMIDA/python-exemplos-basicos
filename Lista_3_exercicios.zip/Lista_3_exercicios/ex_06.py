print("nro\tquad\tcubo")
for i in range(51):  # 0 a 50
    print(f"{i}\t{i**2}\t{i**3}")